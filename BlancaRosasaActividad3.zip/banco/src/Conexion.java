
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
/**
 *
 * @author Jose Servin
 */
public class Conexion {
    public Connection getConection(){
        Connection con = null;
        String base = "banco";
        String url = "jdbc:mysql://localhost:3306/"+ base;
        String user = "root";
        String password = "";
        
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(url, user, password);
           
        }catch (Exception e){
            System.err.println (e);
        }
        return con;
    }
    
}
